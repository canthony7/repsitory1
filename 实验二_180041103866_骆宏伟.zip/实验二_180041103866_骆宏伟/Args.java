package com.zhbit1;

public class Args {
    public static int i = 1;
}
